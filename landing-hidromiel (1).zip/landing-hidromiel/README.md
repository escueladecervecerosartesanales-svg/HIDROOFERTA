# Landing — Curso Premium de Elaboración de Hidromiel

Landing page estática en **un solo archivo**: el HTML ya incluye el diseño, el temporizador,
los datos de pago y **todas las imágenes incrustadas** (base64). No necesita carpeta de
imágenes ni ningún otro archivo. Lista para publicar en **GitHub Pages**.

## Archivos

| Archivo | Descripción |
| --- | --- |
| `index.html` | La página completa con todo incluido: solo sube este archivo |
| `README.md` | Esta guía (opcional) |

## Publicar en GitHub Pages (paso a paso)

1. Inicia sesión en [github.com](https://github.com) y crea un repositorio nuevo
   (botón **`+`** arriba a la derecha → **New repository**).
2. Nómbralo, por ejemplo, `curso-hidromiel` y márcalo como **público**.
3. En la página del repositorio, entra a **"uploading an existing file"**
   (o botón **Add file → Upload files**) y arrastra únicamente `index.html`.
4. Pulsa **Commit changes**.
5. Ve a **Settings → Pages** (menú lateral izquierdo).
6. En **Branch** elige `main` y la carpeta `/ (root)`, y pulsa **Save**.
7. Espera 1–2 minutos y tu página estará disponible en:
   `https://TU_USUARIO.github.io/curso-hidromiel/`

> GitHub Pages sirve el archivo `index.html` automáticamente desde la raíz del repositorio.
> Como las imágenes están incrustadas dentro del HTML, no hay riesgo de que dejen de verse
> si algún archivo se sube incompleto. Si ya habías subido la versión anterior, borra el
> `index.html` viejo y vuelve a subir este.

## Personalización rápida

Todos los cambios se hacen editando `index.html` con cualquier editor de texto:

- **Número de WhatsApp**: busca `52XXXXXXXXXX` y reemplázalo por tu número real
  (formato internacional, sin `+` ni espacios; ejemplo México: `5215512345678`).
- **Hora límite del temporizador**: busca `(22, 30, 0)` en el bloque del script
  y cambia la hora de cierre de la oferta (22:30 = 10:30 PM).
- **Precio**: busca `999`.
- **Datos bancarios**: busca las secciones `pay-card`.

## Temporizador

La cuenta atrás llega hasta las **10:30 PM del día actual**; si la hora pasa,
se reinicia automáticamente hacia las 10:30 PM del día siguiente, de modo que
la oferta siempre muestra un plazo vigente.
